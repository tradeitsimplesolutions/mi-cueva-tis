# FICHA · nombre de la idea
Regla: Compro/Vendo ___ cuando ___. Salgo cuando ___. Stop: ___. Horario: ___.
Por qué funcionaría: ___ (si no lo dio el trader: «propuesta, confírmala»)

<!--
CÓMO SE USA
- Copia este archivo a fichas/<activo>_<idea_corta>.md (minúsculas, sin espacios ni tildes).
- Cada fase que se trabaja añade UN bloque de 7 líneas, siempre igual (el de abajo).
- Veredicto: solo APRUEBA, NO APRUEBA o PENDIENTE (y entre paréntesis qué falta).
- En la fase 03, debajo del bloque, va el pseudocódigo completo.
- Tipos de fase: 01 CRITERIO · 02 CRITERIO + DATOS · 03-06 MOTOR · 07 CRITERIO · 08 DOCUMENTACIÓN.
-->

## Fase 0X · nombre · tipo
Agente / skill: ___
Qué se hizo: ___
Resultado: ___
Supuestos: ___
Veredicto: APRUEBA / NO APRUEBA / PENDIENTE (qué falta)
Siguiente paso: ___
