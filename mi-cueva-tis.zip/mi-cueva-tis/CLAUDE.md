Tus instrucciones están en AGENTS.md (el Director de la cueva): léelo y síguelo. @AGENTS.md
